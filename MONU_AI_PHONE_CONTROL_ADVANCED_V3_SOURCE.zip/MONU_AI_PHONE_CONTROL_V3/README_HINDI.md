# MONU AI PHONE CONTROL — Advanced v3.0

यह Android Studio/Gradle प्रोजेक्ट है। इसे GitHub Actions से Debug APK में बनाया जा सकता है। यह प्रोजेक्ट Samsung/Android फोन के लिए बनाया गया है (min Android 6.0)।

## शामिल सुविधाएँ
- हिंदी Speech Recognition से वॉइस कमांड; ऐप खोलना, Back, Home, Swipe और coordinate Tap (Accessibility चालू होने पर)
- AI बातचीत: OpenAI-compatible Chat Completions API के लिए यूज़र अपनी API key डालता है। API usage पर शुल्क लग सकता है; key निजी रखें।
- Notification Assistant: Android Notification Access अनुमति देने पर हाल के नोटिफिकेशन ऐप के अंदर दिखाता है। नोटिफिकेशन निजी हो सकते हैं।
- Smart Automation: Study/GeoFact/Focus shortcuts (यह अभी सीमित shortcuts हैं, पूरी background automation नहीं)
- कैमरा ऐप खोलना; गैलरी की تصویر पर ML Kit Text Recognition OCR
- Android document picker से PDF/फाइल खोलना
- Battery, Android version, model और उपलब्ध storage की जानकारी
- Emergency contact सेव करना और ACTION_DIAL से डायलर खोलना; ऐप खुद कॉल/SMS नहीं भेजता
- Security & Permissions जानकारी, कमांड हिस्ट्री, GeoFact launcher icon

## महत्वपूर्ण सीमाएँ
1. AI Chat के लिए इंटरनेट और आपकी अपनी API key चाहिए। API key को इस ऐप में सेव करना आपके जोखिम पर है; साझा/पब्लिक डिवाइस पर सेव न करें।
2. Notification Assistant तभी काम करेगा जब आप Android Settings में Notification Access स्पष्ट रूप से चालू करेंगे।
3. Accessibility केवल स्पष्ट यूज़र कमांड पर Back/Home/Swipe/Tap करता है। ऐप छिपकर स्क्रीन नहीं चलाता।
4. Camera button फोन के कैमरा ऐप को खोलता है। OCR के लिए Gallery से फोटो चुनें।
5. Emergency सुविधा केवल नंबर सेव और डायलर खोलती है; कॉल करने से पहले यूज़र पुष्टि करता है।
6. यह ChatGPT की आधिकारिक मोबाइल ऐप या OpenAI का आधिकारिक उत्पाद नहीं है।
7. APK का आकार 5–6 MB निश्चित नहीं किया जा सकता; ML Kit dependency और Android build के कारण आकार बदल सकता है। फ़ाइल का आकार बढ़ाने के लिए बेकार डेटा नहीं जोड़ा गया है।
8. यह Debug APK है, Play Store रिलीज़ के लिए अलग release signing और परीक्षण आवश्यक हैं।

## फोन से GitHub पर अपलोड और APK बनाना
1. ZIP को डाउनलोड करके Extract करें।
2. निकले हुए फ़ोल्डर के अंदर की सभी फ़ाइलें/फ़ोल्डर repository के root में अपलोड करें (ZIP को सीधे repository में न डालें)।
3. GitHub repository → Actions → **Build MONU AI APK** → Run workflow.
4. Workflow सफल होने पर नीचे Artifacts में `monu-ai-phone-control-v3` ZIP डाउनलोड करें। ZIP के अंदर `app-debug.apk` होगा।
5. APK install करते समय Android की Play Protect चेतावनी आए तो उसे पढ़ें; सुरक्षा जांच को बंद न करें। केवल अपने भरोसेमंद build को ही install करें।

## Build
GitHub Actions JDK 17 और Gradle 8.7 से `gradle assembleDebug` चलाता है।
