package com.monu.aiphonecontrol

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.BatteryManager
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.provider.Settings
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.widget.*
import android.graphics.Typeface
import android.graphics.Color
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.mlkit.vision.text.latin.TextRecognizerOptions
import java.net.HttpURLConnection
import java.net.URL
import java.io.OutputStreamWriter
import java.util.Locale
import org.json.JSONObject

class MainActivity : Activity() {
    private lateinit var root: LinearLayout
    private lateinit var commandInput: EditText
    private lateinit var status: TextView
    private lateinit var history: TextView
    private var scanResult: TextView? = null
    private val prefs by lazy { getSharedPreferences("monu_ai", MODE_PRIVATE) }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        refreshHistory()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED)
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
    }

    private fun buildScreen() {
        root = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(18, 20, 18, 14); setBackgroundColor(Color.rgb(245,248,252)) }
        val scroll = ScrollView(this)
        val content = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        content.addView(TextView(this).apply { text = "🌍 MONU AI PHONE CONTROL"; textSize = 22f; setTextColor(Color.rgb(8,43,90)); typeface = Typeface.DEFAULT_BOLD; gravity = Gravity.CENTER })
        content.addView(TextView(this).apply { text = "ADVANCED • हिंदी वॉइस • स्मार्ट टूल्स"; gravity = Gravity.CENTER; textSize = 13f; setPadding(0,8,0,12) })
        commandInput = EditText(this).apply { hint = "कमांड लिखें: YouTube खोलो / back / swipe"; minLines = 2; setPadding(12,10,12,10); setBackgroundColor(Color.WHITE) }
        content.addView(commandInput)
        addButton(content, "🎙 बोलकर कमांड दें") { voiceCommand() }
        addButton(content, "▶ कमांड चलाएँ") { runCommand(commandInput.text.toString()) }
        addButton(content, "📱 इंस्टॉल ऐप्स देखें") { showApps() }
        addButton(content, "⚙ Accessibility अनुमति सेट करें") { startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
        addButton(content, "🤖 AI से बातचीत / API सेटअप") { aiChatDialog() }
        addButton(content, "🔔 Notification Assistant सेट करें") { notificationAssistant() }
        addButton(content, "📷 कैमरा से फोटो / टेक्स्ट स्कैन") { cameraAndScanMenu() }
        addButton(content, "📁 फाइल / PDF खोलें") { openFile() }
        addButton(content, "📊 फोन की जानकारी") { showDeviceInfo() }
        addButton(content, "⚡ Smart Automation रूटीन") { automationMenu() }
        addButton(content, "🆘 Emergency संपर्क") { emergencyDialog() }
        addButton(content, "🛡 अनुमति और सुरक्षा केंद्र") { securityCenter() }
        status = TextView(this).apply { text = "स्थिति: तैयार"; textSize = 14f; setTextColor(Color.rgb(20,100,60)); setPadding(4,12,4,10) }
        content.addView(status)
        scanResult = TextView(this).apply { textSize = 13f; setTextColor(Color.DKGRAY); setPadding(4,6,4,8) }
        content.addView(scanResult)
        content.addView(TextView(this).apply { text = "हाल की कमांड"; textSize = 17f; typeface = Typeface.DEFAULT_BOLD; setTextColor(Color.rgb(8,43,90)) })
        history = TextView(this).apply { textSize = 13f; setTextColor(Color.DKGRAY); setPadding(4,8,4,8) }
        content.addView(history)
        scroll.addView(content); root.addView(scroll); setContentView(root)
    }

    private fun addButton(parent: LinearLayout, label: String, action: () -> Unit) {
        parent.addView(Button(this).apply { text = label; setOnClickListener { action() } }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun voiceCommand() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) { status.text = "Speech Recognition उपलब्ध नहीं"; return }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100); return
        }
        val i = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN"); putExtra(RecognizerIntent.EXTRA_PROMPT, "अपनी कमांड बोलिए")
        }
        try { startActivityForResult(i, 101) } catch (_: Exception) { status.text = "Voice input शुरू नहीं हुआ" }
    }

    @Deprecated("Legacy speech callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK || data == null) return
        when (requestCode) {
            101 -> { val s = data.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty(); commandInput.setText(s); runCommand(s) }
            202 -> data.data?.let { scanImage(it) }
            203 -> data.data?.let { uri ->
                val mime = contentResolver.getType(uri) ?: "*/*"
                try { startActivity(Intent(Intent.ACTION_VIEW).setDataAndType(uri, mime).addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)) }
                catch (_: Exception) { status.text = "इस फाइल को खोलने वाला ऐप नहीं मिला" }
            }
        }
    }

    private fun runCommand(raw: String) {
        val c = raw.trim(); if (c.isEmpty()) { status.text = "पहले कमांड दें"; return }
        val l = c.lowercase(Locale.ROOT)
        when {
            l == "back" || l.contains("वापस") || l.contains("पीछे जाओ") -> sendAccessibility(PhoneAccessibilityService.ACTION_BACK, c)
            l == "home" || l.contains("होम") -> sendAccessibility(PhoneAccessibilityService.ACTION_HOME, c)
            l.contains("swipe") || l.contains("स्वाइप") || l.contains("स्क्रॉल") -> sendAccessibility(PhoneAccessibilityService.ACTION_SWIPE, c)
            l.startsWith("tap") || l.contains("टैप") -> sendAccessibility(PhoneAccessibilityService.ACTION_TAP, c)
            l.contains("खोल") || l.startsWith("open ") -> launchRequestedApp(c)
            else -> { status.text = "कमांड समझ नहीं आई"; saveHistory(c, "समझ नहीं आया") }
        }
    }

    private fun sendAccessibility(action: String, command: String) {
        val ok = PhoneAccessibilityService.execute(action, command)
        if (ok) { status.text = "कमांड पूरी: $command"; saveHistory(command, "पूरी हुई") }
        else { status.text = "पहले Accessibility सेवा चालू करें"; saveHistory(command, "Accessibility अनुमति आवश्यक"); startActivity(Intent(Settings.ACTION_ACCESSIBILITY_SETTINGS)) }
    }

    private fun launchRequestedApp(command: String) {
        val name = command.lowercase(Locale.ROOT).replace("खोल दो", "").replace("खोलो", "").replace("खोल", "").replace("open", "").trim()
        val apps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        val match = apps.firstOrNull { packageManager.getApplicationLabel(it).toString().lowercase(Locale.ROOT).contains(name) }
        val launch = match?.let { packageManager.getLaunchIntentForPackage(it.packageName) }
        if (launch != null) { startActivity(launch); status.text = "ऐप खोला: ${packageManager.getApplicationLabel(match)}"; saveHistory(command,"ऐप खोला गया") }
        else { status.text = "ऐप नहीं मिला: $name"; saveHistory(command,"ऐप नहीं मिला") }
    }

    private fun showApps() {
        val apps = packageManager.getInstalledApplications(PackageManager.GET_META_DATA).filter { packageManager.getLaunchIntentForPackage(it.packageName) != null }.sortedBy { packageManager.getApplicationLabel(it).toString() }
        val names = apps.map { packageManager.getApplicationLabel(it).toString() }
        android.app.AlertDialog.Builder(this).setTitle("ऐप चुनें").setItems(names.toTypedArray()) { _, n -> packageManager.getLaunchIntentForPackage(apps[n].packageName)?.let { startActivity(it) } }.setNegativeButton("बंद",null).show()
    }

    private fun aiChatDialog() {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL; setPadding(20,8,20,4) }
        val key = EditText(this).apply { hint = "OpenAI API key (केवल अपने डिवाइस पर)"; setText(prefs.getString("ai_key", "")); inputType = 129 }
        val prompt = EditText(this).apply { hint = "AI से अपना सवाल पूछें"; minLines = 2 }
        box.addView(key); box.addView(prompt)
        android.app.AlertDialog.Builder(this).setTitle("AI Chat सेटअप").setMessage("AI बातचीत के लिए इंटरनेट और अपनी API key जरूरी है। API key किसी के साथ साझा न करें।").setView(box)
            .setPositiveButton("पूछें") { _, _ -> prefs.edit().putString("ai_key",key.text.toString().trim()).apply(); askAi(prompt.text.toString().trim(), key.text.toString().trim()) }
            .setNeutralButton("सिर्फ API key सेव करें") { _, _ -> prefs.edit().putString("ai_key",key.text.toString().trim()).apply(); status.text="API key सेव की गई" }.setNegativeButton("रद्द",null).show()
    }

    private fun askAi(question: String, key: String) {
        if (question.isBlank() || key.isBlank()) { status.text = "सवाल और API key दोनों जरूरी हैं"; return }
        status.text = "AI जवाब तैयार कर रहा है…"
        Thread {
            try {
                val conn = (URL("https://api.openai.com/v1/chat/completions").openConnection() as HttpURLConnection)
                conn.requestMethod="POST"; conn.connectTimeout=20000; conn.readTimeout=30000; conn.doOutput=true
                conn.setRequestProperty("Authorization","Bearer $key"); conn.setRequestProperty("Content-Type","application/json")
                val body = JSONObject().put("model","gpt-4o-mini").put("messages", org.json.JSONArray().put(JSONObject().put("role","system").put("content","हिंदी में सरल और सुरक्षित उत्तर दें। फोन पर कोई कार्रवाई स्वयं न करें।")).put(JSONObject().put("role","user").put("content",question))).toString()
                OutputStreamWriter(conn.outputStream).use { it.write(body) }
                val stream = if(conn.responseCode in 200..299) conn.inputStream else conn.errorStream
                val response = stream.bufferedReader().use { it.readText() }; conn.disconnect()
                val json=JSONObject(response); val answer=json.optJSONArray("choices")?.optJSONObject(0)?.optJSONObject("message")?.optString("content") ?: json.optString("error",response)
                runOnUiThread { status.text="AI: $answer"; saveHistory("AI: $question","जवाब प्राप्त") }
            } catch(e: Exception) { runOnUiThread { status.text="AI कनेक्शन त्रुटि: ${e.localizedMessage}" } }
        }.start()
    }

    private fun notificationAssistant() {
        startActivity(Intent("android.settings.ACTION_NOTIFICATION_LISTENER_SETTINGS"))
        val saved=prefs.getString("notifications","").orEmpty()
        android.app.AlertDialog.Builder(this).setTitle("हाल के नोटिफिकेशन").setMessage(if(saved.isBlank()) "अभी नोटिफिकेशन उपलब्ध नहीं। पहले Notification Access अनुमति दें।" else saved.take(3500)).setPositiveButton("ठीक",null).show()
    }

    private fun cameraAndScanMenu() {
        android.app.AlertDialog.Builder(this).setTitle("कैमरा और टेक्स्ट स्कैन").setItems(arrayOf("कैमरा खोलें","गैलरी से फोटो चुनकर टेक्स्ट पढ़ें")) { _, which ->
            if(which==0) try { startActivity(Intent(MediaStore.ACTION_IMAGE_CAPTURE)) } catch (_:Exception) { status.text="कैमरा ऐप नहीं मिला" }
            else { val i=Intent(Intent.ACTION_OPEN_DOCUMENT).setType("image/*").addCategory(Intent.CATEGORY_OPENABLE); startActivityForResult(i,202) }
        }.show()
    }

    private fun scanImage(uri: Uri) {
        status.text="फोटो में टेक्स्ट पढ़ रहे हैं…"
        try {
            val image=InputImage.fromFilePath(this,uri); val recognizer=TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)
            recognizer.process(image).addOnSuccessListener { result -> scanResult?.text="स्कैन किया गया टेक्स्ट:\n${result.text.ifBlank { "कोई टेक्स्ट नहीं मिला" }}"; status.text="स्कैन पूरा"; saveHistory("Image OCR","टेक्स्ट निकाला गया"); recognizer.close() }
                .addOnFailureListener { e -> status.text="OCR त्रुटि: ${e.localizedMessage}"; recognizer.close() }
        } catch(e:Exception) { status.text="फोटो पढ़ नहीं पाए: ${e.localizedMessage}" }
    }

    private fun openFile() { val i=Intent(Intent.ACTION_OPEN_DOCUMENT).addCategory(Intent.CATEGORY_OPENABLE).setType("*/*"); startActivityForResult(i,203) }

    private fun showDeviceInfo() {
        val bm=getSystemService(BATTERY_SERVICE) as BatteryManager
        val battery=bm.getIntProperty(BatteryManager.BATTERY_PROPERTY_CAPACITY)
        val runtime=Runtime.getRuntime(); val used=(runtime.totalMemory()-runtime.freeMemory())/1024/1024; val max=runtime.maxMemory()/1024/1024
        val stat=Environment.getDataDirectory().usableSpace/1024/1024/1024.0
        android.app.AlertDialog.Builder(this).setTitle("फोन की जानकारी").setMessage("Android: ${android.os.Build.VERSION.RELEASE}\nडिवाइस: ${android.os.Build.MANUFACTURER} ${android.os.Build.MODEL}\nबैटरी: $battery%\nऐप मेमोरी: $used MB / $max MB\nउपलब्ध इंटरनल स्टोरेज: %.2f GB".format(stat)).setPositiveButton("ठीक",null).show()
    }

    private fun automationMenu() {
        android.app.AlertDialog.Builder(this).setTitle("Smart Automation").setItems(arrayOf("Study Mode: YouTube/Browser खोलें","GeoFact Mode: कैमरा और फाइल टूल खोलें","Focus Mode: Do Not Disturb सेटिंग खोलें")) { _, n ->
            when(n) { 0 -> launchByName("Chrome") ?: launchByName("YouTube"); 1 -> cameraAndScanMenu(); 2 -> startActivity(Intent(Settings.ACTION_SOUND_SETTINGS)) }
            saveHistory("Automation $n","रूटीन शुरू")
        }.show()
    }
    private fun launchByName(name:String): Unit? { val app=packageManager.getInstalledApplications(0).firstOrNull { packageManager.getApplicationLabel(it).toString().contains(name,true) } ?: return null; packageManager.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) }; return Unit }

    private fun emergencyDialog() {
        val phone=EditText(this).apply { hint="आपातकालीन संपर्क नंबर"; inputType=3; setText(prefs.getString("emergency_phone", "")) }
        android.app.AlertDialog.Builder(this).setTitle("Emergency Mode").setMessage("नंबर सेव करें या डायलर खोलें। कॉल/मैसेज भेजने से पहले आप स्वयं पुष्टि करेंगे।").setView(phone)
            .setPositiveButton("नंबर सेव करें") { _, _ -> prefs.edit().putString("emergency_phone",phone.text.toString()).apply(); status.text="Emergency नंबर सेव" }
            .setNeutralButton("डायलर खोलें") { _, _ -> val n=phone.text.toString().ifBlank { prefs.getString("emergency_phone","").orEmpty() }; if(n.isNotBlank()) startActivity(Intent(Intent.ACTION_DIAL,Uri.parse("tel:$n"))) else status.text="पहले नंबर दर्ज करें" }
            .setNegativeButton("रद्द",null).show()
    }

    private fun securityCenter() {
        val msg="MONU AI केवल आपकी दी हुई अनुमति से काम करता है।\n• Accessibility: स्क्रीन नेविगेशन/जेस्चर के लिए\n• Microphone: वॉइस कमांड के लिए\n• Notification Access: नोटिफिकेशन पढ़ने के लिए\n• Camera/Photos: स्कैन के लिए\n• AI API key: इंटरनेट पर AI सेवा से जुड़ने के लिए\nकिसी अनजान व्यक्ति को API key न दें।"
        android.app.AlertDialog.Builder(this).setTitle("Security & Permissions").setMessage(msg).setPositiveButton("ऐप अनुमति सेटिंग") { _, _ -> startActivity(Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS,Uri.parse("package:$packageName"))) }.setNegativeButton("ठीक",null).show()
    }

    private fun saveHistory(command:String,result:String) { val old=prefs.getString("history","").orEmpty(); prefs.edit().putString("history",("• $command — $result\n"+old).lines().take(20).joinToString("\n")).apply(); refreshHistory() }
    private fun refreshHistory() { if(::history.isInitialized) history.text=prefs.getString("history","अभी कोई कमांड नहीं").orEmpty() }
}
