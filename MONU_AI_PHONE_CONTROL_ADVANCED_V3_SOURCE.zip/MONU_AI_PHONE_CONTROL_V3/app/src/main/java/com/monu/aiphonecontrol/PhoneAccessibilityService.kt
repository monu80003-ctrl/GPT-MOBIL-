package com.monu.aiphonecontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.graphics.Path
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class PhoneAccessibilityService : AccessibilityService() {
    companion object {
        const val ACTION_BACK = "BACK"; const val ACTION_HOME = "HOME"; const val ACTION_TAP = "TAP"; const val ACTION_SWIPE = "SWIPE"
        @Volatile var active: PhoneAccessibilityService? = null
        fun execute(action:String, command:String): Boolean = active?.performCommand(action,command) ?: false
    }
    override fun onServiceConnected() { super.onServiceConnected(); active=this }
    override fun onDestroy() { if(active===this) active=null; super.onDestroy() }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) { }
    override fun onInterrupt() { }
    fun performCommand(action:String, command:String):Boolean {
        return when(action) {
            ACTION_BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            ACTION_HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
            ACTION_SWIPE -> performSwipe()
            ACTION_TAP -> performTap(command)
            else -> false
        }
    }
    private fun performTap(command:String):Boolean {
        val nums=Regex("\\d+").findAll(command).mapNotNull { it.value.toFloatOrNull() }.toList()
        if(nums.size<2) { Toast.makeText(this,"लिखें: tap 350 700",Toast.LENGTH_LONG).show(); return false }
        val path=Path().apply { moveTo(nums[0],nums[1]) }
        val gesture=GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,120)).build()
        return dispatchGesture(gesture,null,null)
    }
    private fun performSwipe():Boolean {
        val dm=resources.displayMetrics; val x=dm.widthPixels/2f; val path=Path().apply { moveTo(x,dm.heightPixels*.78f); lineTo(x,dm.heightPixels*.28f) }
        val gesture=GestureDescription.Builder().addStroke(GestureDescription.StrokeDescription(path,0,350)).build()
        return dispatchGesture(gesture,null,null)
    }
}
