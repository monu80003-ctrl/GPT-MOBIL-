package com.monu.aiphonecontrol

import android.service.notification.NotificationListenerService
import android.service.notification.StatusBarNotification

class MonuNotificationListener : NotificationListenerService() {
    override fun onNotificationPosted(sbn: StatusBarNotification?) {
        val n = sbn?.notification ?: return
        val extras = n.extras
        val title = extras.getCharSequence("android.title")?.toString().orEmpty()
        val body = extras.getCharSequence("android.text")?.toString().orEmpty()
        if (title.isNotBlank() || body.isNotBlank()) {
            val p = getSharedPreferences("monu_ai", MODE_PRIVATE)
            val line = "${sbn.packageName}: $title — $body"
            val old = p.getString("notifications", "").orEmpty()
            p.edit().putString("notifications", (line + "\n" + old).lines().take(30).joinToString("\n")).apply()
        }
    }
}
