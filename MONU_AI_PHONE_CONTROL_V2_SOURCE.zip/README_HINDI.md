# MONU AI PHONE CONTROL V2

यह Android Studio / GitHub Actions के लिए पूरा Android प्रोजेक्ट है।

## शामिल फीचर्स
1. हिंदी/English voice input (फोन के Speech Recognition ऐप पर निर्भर)
2. इंस्टॉल किए गए ऐप्स की सूची और ऐप खोलना
3. Accessibility Service से Back और Home
4. Accessibility Service से Swipe
5. निर्देशित coordinates से Tap: `tap 350 700`
6. हाल के 20 कमांड की हिस्ट्री
7. Accessibility और माइक्रोफोन अनुमति सेटिंग

## GitHub पर अपलोड
1. ZIP को फोन में डाउनलोड करके Extract करें।
2. Extract किए गए फ़ोल्डर के अंदर की सभी फाइलें अपने GitHub repository के root में अपलोड करें।
3. GitHub Actions टैब खोलें। `Build MONU AI APK` workflow चुनकर `Run workflow` दबाएँ।
4. सफल होने पर workflow run के Artifacts सेक्शन से `monu-ai-phone-control-v2` ZIP डाउनलोड करें।
5. ZIP Extract करके `app-debug.apk` इंस्टॉल करें।

## पहली बार सेटअप
1. ऐप खोलें।
2. `Accessibility चालू करने की सेटिंग` दबाएँ।
3. Installed/Downloaded services में `MONU AI Phone Control` खोलकर अनुमति दें।
4. Voice command के लिए माइक्रोफोन अनुमति दें।

## उदाहरण
- `YouTube खोलो`
- `Chrome खोलो`
- `back` या `वापस`
- `home` या `होम`
- `नीचे स्क्रॉल` / `swipe`
- `tap 350 700` (स्क्रीन के pixel coordinates)

## सुरक्षा और सीमाएँ
- ऐप अपने आप फोन की हर चीज़ नियंत्रित नहीं करता। केवल ऊपर दिए गए कमांड लागू हैं।
- Accessibility अनुमति बहुत शक्तिशाली होती है। इसे केवल अपने भरोसेमंद, स्वयं बनाए ऐप को दें।
- Voice recognition Android के Speech Recognition provider और इंटरनेट/ऑफलाइन भाषा पैक पर निर्भर कर सकता है।
- यह संस्करण ChatGPT/क्लाउड AI से कनेक्ट नहीं है; अभी यह लोकल कमांड प्रोटोटाइप है।
- APK का आकार फीचर्स, Android build tools और resources के अनुसार बदलता है। 5–6 MB की गारंटी नहीं है।
- यह debug APK है, Play Store release package नहीं।
