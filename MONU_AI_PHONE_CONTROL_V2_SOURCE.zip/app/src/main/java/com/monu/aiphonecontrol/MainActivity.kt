package com.monu.aiphonecontrol

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.os.Bundle
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Typeface
import android.graphics.Color
import androidx.core.app.ActivityCompat
import androidx.core.content.ContextCompat
import java.util.Locale

class MainActivity : Activity() {
    private lateinit var commandInput: EditText
    private lateinit var status: TextView
    private lateinit var history: TextView
    private var speechRecognizer: SpeechRecognizer? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        buildScreen()
        refreshHistory()
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100)
        }
    }

    private fun buildScreen() {
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(22, 24, 22, 18)
            setBackgroundColor(Color.rgb(246, 249, 253))
        }
        val title = TextView(this).apply {
            text = "🌍  MONU AI PHONE CONTROL"
            textSize = 22f
            setTextColor(Color.rgb(8, 43, 90))
            typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, -2))
        root.addView(TextView(this).apply {
            text = "हिंदी या English में कमांड दें"
            textSize = 15f; gravity = Gravity.CENTER; setPadding(0, 10, 0, 16)
        })
        commandInput = EditText(this).apply {
            hint = "जैसे: YouTube खोलो / back / home"
            textSize = 16f
            setSingleLine(false)
            minLines = 2
            setPadding(14, 10, 14, 10)
            setBackgroundColor(Color.WHITE)
        }
        root.addView(commandInput, LinearLayout.LayoutParams(-1, -2))
        val voice = Button(this).apply { text = "🎙 बोलकर कमांड दें"; setOnClickListener { startVoiceInput() } }
        root.addView(voice, LinearLayout.LayoutParams(-1, -2))
        val run = Button(this).apply { text = "कमांड चलाएँ"; setOnClickListener { runCommand(commandInput.text.toString()) } }
        root.addView(run, LinearLayout.LayoutParams(-1, -2))
        val apps = Button(this).apply { text = "इंस्टॉल ऐप्स देखें"; setOnClickListener { showApps() } }
        root.addView(apps, LinearLayout.LayoutParams(-1, -2))
        val permission = Button(this).apply { text = "Accessibility चालू करने की सेटिंग"; setOnClickListener {
            startActivity(Intent(android.provider.Settings.ACTION_ACCESSIBILITY_SETTINGS))
        } }
        root.addView(permission, LinearLayout.LayoutParams(-1, -2))
        status = TextView(this).apply {
            text = "स्थिति: तैयार"
            textSize = 14f; setTextColor(Color.rgb(20, 100, 60)); setPadding(4, 12, 4, 12)
        }
        root.addView(status)
        root.addView(TextView(this).apply {
            text = "कमांड हिस्ट्री"; textSize = 18f; typeface = Typeface.DEFAULT_BOLD
            setTextColor(Color.rgb(8, 43, 90))
        })
        history = TextView(this).apply { textSize = 13f; setTextColor(Color.DKGRAY); setPadding(4, 8, 4, 8) }
        val scroll = ScrollView(this)
        scroll.addView(history)
        root.addView(scroll, LinearLayout.LayoutParams(-1, 0, 1f))
        setContentView(root)
    }

    private fun startVoiceInput() {
        if (!SpeechRecognizer.isRecognitionAvailable(this)) {
            status.text = "इस फोन पर Speech Recognition उपलब्ध नहीं है"; return
        }
        if (ContextCompat.checkSelfPermission(this, Manifest.permission.RECORD_AUDIO) != PackageManager.PERMISSION_GRANTED) {
            ActivityCompat.requestPermissions(this, arrayOf(Manifest.permission.RECORD_AUDIO), 100); return
        }
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_LANGUAGE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, "hi-IN")
            putExtra(RecognizerIntent.EXTRA_PROMPT, "अपनी कमांड बोलिए")
        }
        try { startActivityForResult(intent, 101) }
        catch (_: Exception) { status.text = "Voice input शुरू नहीं हो सका" }
    }

    @Deprecated("Legacy speech result callback")
    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode == 101 && resultCode == RESULT_OK) {
            val spoken = data?.getStringArrayListExtra(RecognizerIntent.EXTRA_RESULTS)?.firstOrNull().orEmpty()
            commandInput.setText(spoken)
            runCommand(spoken)
        }
    }

    private fun runCommand(raw: String) {
        val command = raw.trim()
        if (command.isEmpty()) { status.text = "पहले कमांड लिखें या बोलें"; return }
        val lower = command.lowercase(Locale.ROOT)
        when {
            lower == "back" || lower.contains("वापस") || lower.contains("पीछे जाओ") ->
                sendAccessibility(PhoneAccessibilityService.ACTION_BACK, command)
            lower == "home" || lower.contains("होम") || lower.contains("होम स्क्रीन") ->
                sendAccessibility(PhoneAccessibilityService.ACTION_HOME, command)
            lower.startsWith("swipe") || lower.contains("स्वाइप") || lower.contains("नीचे स्क्रॉल") ->
                sendAccessibility(PhoneAccessibilityService.ACTION_SWIPE, command)
            lower.startsWith("tap ") || lower.contains("टैप") ->
                sendAccessibility(PhoneAccessibilityService.ACTION_TAP, command)
            lower.contains("खोल") || lower.startsWith("open ") ->
                launchRequestedApp(command)
            else -> {
                status.text = "कमांड समझ नहीं आई। उदाहरण: YouTube खोलो, back, home"
                saveHistory(command, "समझ नहीं आया")
            }
        }
    }

    private fun sendAccessibility(action: String, command: String) {
        val intent = Intent(this, PhoneAccessibilityService::class.java).apply {
            this.action = action
            putExtra("command", command)
        }
        try {
            startService(intent)
            status.text = "कमांड भेजी: $command"
            saveHistory(command, "भेजी गई — Accessibility चालू होना जरूरी है")
        } catch (_: Exception) {
            status.text = "Accessibility Service उपलब्ध नहीं है"
            saveHistory(command, "सेवा उपलब्ध नहीं")
        }
    }

    private fun launchRequestedApp(command: String) {
        val name = command.lowercase(Locale.ROOT)
            .replace("खोल दो", "").replace("खोलो", "").replace("खोल", "")
            .replace("open", "").trim()
        val candidates = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
        val match = candidates.firstOrNull {
            val label = packageManager.getApplicationLabel(it).toString().lowercase(Locale.ROOT)
            label.contains(name) || name.contains(label)
        }
        if (match != null) {
            val launch = packageManager.getLaunchIntentForPackage(match.packageName)
            if (launch != null) {
                startActivity(launch); status.text = "खोल रहे हैं: ${packageManager.getApplicationLabel(match)}"
                saveHistory(command, "ऐप खोला गया"); return
            }
        }
        status.text = "ऐप नहीं मिला: $name"
        saveHistory(command, "ऐप नहीं मिला")
    }

    private fun showApps() {
        val items = packageManager.getInstalledApplications(PackageManager.GET_META_DATA)
            .filter { packageManager.getLaunchIntentForPackage(it.packageName) != null }
            .sortedBy { packageManager.getApplicationLabel(it).toString() }
        val names = items.map { packageManager.getApplicationLabel(it).toString() }
        AlertDialogBuilder.show(this, names) { selected ->
            val app = items[selected]
            packageManager.getLaunchIntentForPackage(app.packageName)?.let { startActivity(it) }
            saveHistory("ऐप सूची: ${names[selected]}", "खोला गया")
        }
    }

    private fun saveHistory(command: String, result: String) {
        val prefs = getSharedPreferences("monu_ai", MODE_PRIVATE)
        val old = prefs.getString("history", "").orEmpty()
        val next = ("• $command — $result\n" + old).lines().take(20).joinToString("\n")
        prefs.edit().putString("history", next).apply()
        refreshHistory()
    }

    private fun refreshHistory() {
        if (::history.isInitialized) history.text = getSharedPreferences("monu_ai", MODE_PRIVATE).getString("history", "अभी कोई कमांड नहीं").orEmpty()
    }

    override fun onDestroy() {
        speechRecognizer?.destroy()
        super.onDestroy()
    }
}

private object AlertDialogBuilder {
    fun show(activity: Activity, items: List<String>, onSelect: (Int) -> Unit) {
        android.app.AlertDialog.Builder(activity)
            .setTitle("ऐप चुनें")
            .setItems(items.toTypedArray()) { _, which -> onSelect(which) }
            .setNegativeButton("बंद करें", null)
            .show()
    }
}
