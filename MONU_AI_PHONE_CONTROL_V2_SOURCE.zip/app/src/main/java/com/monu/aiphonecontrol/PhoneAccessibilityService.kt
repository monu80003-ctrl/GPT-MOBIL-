package com.monu.aiphonecontrol

import android.accessibilityservice.AccessibilityService
import android.accessibilityservice.GestureDescription
import android.content.Intent
import android.graphics.Path
import android.os.Bundle
import android.view.accessibility.AccessibilityEvent
import android.widget.Toast

class PhoneAccessibilityService : AccessibilityService() {
    companion object {
        const val ACTION_BACK = "com.monu.aiphonecontrol.BACK"
        const val ACTION_HOME = "com.monu.aiphonecontrol.HOME"
        const val ACTION_TAP = "com.monu.aiphonecontrol.TAP"
        const val ACTION_SWIPE = "com.monu.aiphonecontrol.SWIPE"
    }

    override fun onAccessibilityEvent(event: AccessibilityEvent?) { /* Events are not recorded. */ }
    override fun onInterrupt() { }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        when (intent?.action) {
            ACTION_BACK -> performGlobalAction(GLOBAL_ACTION_BACK)
            ACTION_HOME -> performGlobalAction(GLOBAL_ACTION_HOME)
            ACTION_TAP -> performTap(intent.getStringExtra("command").orEmpty())
            ACTION_SWIPE -> performSwipe()
        }
        return START_NOT_STICKY
    }

    private fun performTap(command: String) {
        val nums = Regex("\\d+").findAll(command).mapNotNull { it.value.toFloatOrNull() }.toList()
        if (nums.size < 2) {
            Toast.makeText(this, "Tap के लिए लिखें: tap 350 700", Toast.LENGTH_LONG).show()
            return
        }
        val path = Path().apply { moveTo(nums[0], nums[1]) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 120))
            .build()
        dispatchGesture(gesture, null, null)
    }

    private fun performSwipe() {
        val dm = resources.displayMetrics
        val x = dm.widthPixels / 2f
        val startY = dm.heightPixels * 0.78f
        val endY = dm.heightPixels * 0.28f
        val path = Path().apply { moveTo(x, startY); lineTo(x, endY) }
        val gesture = GestureDescription.Builder()
            .addStroke(GestureDescription.StrokeDescription(path, 0, 350))
            .build()
        dispatchGesture(gesture, null, null)
    }
}
